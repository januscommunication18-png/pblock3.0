@extends('projects.settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/projects/general.js') }}"></script>
@endpush
