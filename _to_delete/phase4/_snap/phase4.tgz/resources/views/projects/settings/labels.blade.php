@extends('projects.settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/projects/labels.js') }}"></script>
@endpush
