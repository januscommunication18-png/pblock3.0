@extends('projects.settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/projects/members.js') }}"></script>
@endpush
