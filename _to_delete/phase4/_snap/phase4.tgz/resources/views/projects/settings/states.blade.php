@extends('projects.settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/projects/states.js') }}"></script>
@endpush
