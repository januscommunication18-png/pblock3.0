<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * projects (Phase 4) — a project inside a workspace (PRJ-001/002). TENANT-SCOPED via
 * App\Models\Project (BelongsToTenant): once tenancy is initialized every query is confined
 * to the active workspace. UNIQUE(tenant_id, identifier) enforces workspace-scoped identifier
 * uniqueness (PRJ-022 / §5) — the same identifier may exist in a different workspace.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->string('tenant_id'); // -> tenants.id
            $table->string('name');
            $table->string('identifier', 10);
            $table->text('description')->nullable();
            $table->string('visibility', 10)->default('public'); // public | private
            $table->foreignId('lead_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('cover_url')->nullable();
            $table->string('cover_gradient')->nullable();
            $table->string('emoji', 16)->nullable();
            $table->string('timezone')->nullable();
            $table->string('status', 10)->default('active'); // active | archived
            $table->json('features')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('archived_at')->nullable();
            $table->timestamps();

            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->unique(['tenant_id', 'identifier']);
            $table->index(['tenant_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};
