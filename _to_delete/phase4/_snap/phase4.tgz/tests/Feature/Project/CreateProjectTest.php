<?php

namespace Tests\Feature\Project;

use App\Models\Project;
use App\Models\ProjectItemState;
use App\Models\ProjectMember;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

/** Create Project (PRJ-020..028), permissions and identifier uniqueness. */
class CreateProjectTest extends ProjectTestCase
{
    use RefreshDatabase;

    public function test_owner_can_create_project_with_creator_admin_and_seeded_states(): void
    {
        [$owner, $workspace] = $this->owner();
        $lead = $this->member($workspace, 'member', 'lead@example.com');

        $this->actingAs($owner)->postJson(route('projects.store'), [
            'name' => 'Website Redesign 2026', 'identifier' => 'WEB', 'visibility' => 'private',
            'description' => 'Marketing site', 'lead_user_id' => $lead->id,
        ])->assertOk()->assertJsonPath('project.identifier', 'WEB');

        $project = $workspace->run(fn () => Project::first());
        $this->assertSame('private', $project->visibility);
        $this->assertSame($lead->id, $project->lead_user_id);
        $this->assertSame($owner->id, $project->created_by);

        // Creator is a project admin; lead is a member; default states seeded.
        $this->assertTrue($workspace->run(fn () => ProjectMember::where('project_id', $project->id)->where('user_id', $owner->id)->where('role', 'admin')->exists()));
        $this->assertTrue($workspace->run(fn () => ProjectMember::where('project_id', $project->id)->where('user_id', $lead->id)->where('role', 'member')->exists()));
        $this->assertGreaterThan(0, $workspace->run(fn () => ProjectItemState::where('project_id', $project->id)->count()));
    }

    public function test_member_viewer_guest_cannot_create(): void
    {
        [, $workspace] = $this->owner();

        foreach (['member', 'viewer', 'guest'] as $role) {
            $user = $this->member($workspace, $role, "{$role}@example.com");
            $this->actingAs($user)->postJson(route('projects.store'), [
                'name' => 'X', 'identifier' => 'X'.strtoupper($role[0]), 'visibility' => 'public',
            ])->assertForbidden();
        }
        $this->assertSame(0, $workspace->run(fn () => Project::count()));
    }

    public function test_name_required_and_identifier_required(): void
    {
        [$owner] = $this->owner();

        $this->actingAs($owner)->postJson(route('projects.store'), [
            'name' => '   ', 'identifier' => '', 'visibility' => 'public',
        ])->assertStatus(422)->assertJsonValidationErrors(['name', 'identifier']);
    }

    public function test_identifier_is_unique_within_workspace_but_reusable_across_workspaces(): void
    {
        [$ownerA, $wsA] = $this->owner('acme');
        [$ownerB] = $this->owner('beta');

        $this->actingAs($ownerA)->postJson(route('projects.store'), ['name' => 'One', 'identifier' => 'DUP', 'visibility' => 'public'])->assertOk();
        // Same identifier again in workspace A → rejected.
        $this->actingAs($ownerA)->postJson(route('projects.store'), ['name' => 'Two', 'identifier' => 'DUP', 'visibility' => 'public'])
            ->assertStatus(422)->assertJsonValidationErrors('identifier');
        // Same identifier in workspace B → allowed.
        $this->actingAs($ownerB)->postJson(route('projects.store'), ['name' => 'Other', 'identifier' => 'DUP', 'visibility' => 'public'])->assertOk();

        $this->assertSame(1, $wsA->run(fn () => Project::count()));
    }

    public function test_identifier_availability_endpoint(): void
    {
        [$owner, $workspace] = $this->owner();
        $this->makeProject($workspace, $owner, ['identifier' => 'TAKEN']);

        $this->actingAs($owner)->getJson(route('projects.identifier', ['identifier' => 'taken']))
            ->assertOk()->assertJson(['identifier' => 'TAKEN', 'available' => false]);
        $this->actingAs($owner)->getJson(route('projects.identifier', ['identifier' => 'fresh1']))
            ->assertOk()->assertJson(['available' => true]);
    }

    public function test_lead_must_be_a_workspace_member(): void
    {
        [$owner] = $this->owner();
        $outsider = User::factory()->create();

        $this->actingAs($owner)->postJson(route('projects.store'), [
            'name' => 'X', 'identifier' => 'XX', 'visibility' => 'public', 'lead_user_id' => $outsider->id,
        ])->assertStatus(422)->assertJsonValidationErrors('lead_user_id');
    }

    public function test_unlimited_projects_are_not_blocked_by_a_count_threshold(): void
    {
        [$owner, $workspace] = $this->owner();

        for ($i = 1; $i <= 12; $i++) {
            $this->actingAs($owner)->postJson(route('projects.store'), [
                'name' => "P{$i}", 'identifier' => 'P'.$i, 'visibility' => 'public',
            ])->assertOk();
        }
        $this->assertSame(12, $workspace->run(fn () => Project::count()));
    }
}
