<?php

namespace Tests\Feature\Project;

use App\Models\Project;
use App\Models\User;
use App\Models\Workspace;
use App\Models\WorkspaceMembership;
use App\Services\ProjectCreator;
use App\Services\WorkspaceCreator;
use Tests\TestCase;

/** Shared setup for Phase 4 project feature tests. */
abstract class ProjectTestCase extends TestCase
{
    /** @return array{0: User, 1: Workspace} owner (fresh) + their workspace */
    protected function owner(string $slug = 'acme'): array
    {
        $user = User::factory()->create(['full_name' => 'Rohit', 'email' => "owner-{$slug}@example.com"]);
        $workspace = app(WorkspaceCreator::class)->create($user, [
            'name' => 'Acme', 'slug' => $slug, 'company_size' => '2-10',
        ]);

        return [$user->fresh(), $workspace];
    }

    protected function member(Workspace $workspace, string $role, string $email): User
    {
        $user = User::factory()->create(['email' => $email]);
        WorkspaceMembership::create([
            'workspace_id' => $workspace->id, 'user_id' => $user->id,
            'role' => $role, 'status' => 'active', 'joined_at' => now(),
        ]);
        $user->forceFill(['current_workspace_id' => $workspace->id])->save();

        return $user->fresh();
    }

    /** Create a project via the service (bypasses the create policy for arrange steps). */
    protected function makeProject(Workspace $workspace, User $creator, array $overrides = []): Project
    {
        return app(ProjectCreator::class)->create($workspace, $creator, array_merge([
            'name' => 'Website', 'identifier' => 'WEB', 'visibility' => 'public',
        ], $overrides));
    }
}
