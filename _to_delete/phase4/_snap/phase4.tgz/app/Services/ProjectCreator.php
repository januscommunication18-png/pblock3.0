<?php

namespace App\Services;

use App\Models\Project;
use App\Models\ProjectItemState;
use App\Models\ProjectMember;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Support\Facades\DB;

/**
 * Creates a project atomically together with its creator (project admin) membership, an
 * optional lead membership, and the seeded default work-item states (PRJ-020/026/043).
 *
 * Runs inside the workspace's tenancy context so BelongsToTenant stamps/scopes tenant_id.
 * The unique (tenant_id, identifier) constraint makes double-submits safe (PRJ-022).
 *
 * @phpstan-type ProjectData array{name:string, identifier:string, description?:string|null,
 *   visibility:string, lead_user_id?:int|null, cover_gradient?:string|null, emoji?:string|null,
 *   timezone?:string|null}
 */
class ProjectCreator
{
    public function create(Workspace $workspace, User $creator, array $data): Project
    {
        return $workspace->run(function () use ($workspace, $creator, $data) {
            return DB::transaction(function () use ($workspace, $creator, $data) {
                $project = Project::create([
                    'tenant_id' => $workspace->id,
                    'name' => $data['name'],
                    'identifier' => strtoupper($data['identifier']),
                    'description' => $data['description'] ?? null,
                    'visibility' => $data['visibility'],
                    'lead_user_id' => $data['lead_user_id'] ?? null,
                    'cover_gradient' => $data['cover_gradient'] ?? config('projects.cover_presets')[0],
                    'emoji' => $data['emoji'] ?? null,
                    'timezone' => $data['timezone'] ?? $workspace->timezone,
                    'status' => Project::STATUS_ACTIVE,
                    'features' => collect(config('projects.features'))->map(fn ($f) => (bool) $f['default'])->all(),
                    'created_by' => $creator->id,
                ]);

                // Creator is the project admin (PRJ-041).
                ProjectMember::create([
                    'project_id' => $project->id,
                    'user_id' => $creator->id,
                    'role' => ProjectMember::ROLE_ADMIN,
                ]);

                // The chosen lead becomes a project member (PRJ-026).
                $leadId = $data['lead_user_id'] ?? null;
                if ($leadId && (int) $leadId !== (int) $creator->id) {
                    ProjectMember::create([
                        'project_id' => $project->id,
                        'user_id' => $leadId,
                        'role' => ProjectMember::ROLE_MEMBER,
                    ]);
                }

                $this->seedDefaultStates($project);

                return $project;
            });
        });
    }

    /** Seed the configured default work-item states for a new project (PRJ-043). */
    private function seedDefaultStates(Project $project): void
    {
        foreach (array_values(config('projects.default_states')) as $i => $state) {
            ProjectItemState::create([
                'project_id' => $project->id,
                'name' => $state['name'],
                'color' => $state['color'],
                'group' => $state['group'],
                'is_default' => $state['is_default'],
                'position' => $i,
            ]);
        }
    }
}
