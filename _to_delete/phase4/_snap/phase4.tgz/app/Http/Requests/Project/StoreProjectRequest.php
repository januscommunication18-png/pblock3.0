<?php

namespace App\Http\Requests\Project;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Create Project validation (PRJ-021..027). Identifier is normalized to uppercase A–Z/0–9 and
 * must be unique within the active workspace (case-insensitive via the stored uppercase form).
 * The lead, if given, must be a member of the current workspace (PRJ-026).
 */
class StoreProjectRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // authorization handled in the controller via ProjectPolicy
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
            'identifier' => strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $this->input('identifier'))),
        ]);
    }

    public function rules(): array
    {
        $workspaceId = $this->user()->current_workspace_id;

        return [
            'name' => ['required', 'string', 'max:120'],
            'identifier' => [
                'required', 'string', 'max:10',
                'regex:/^[A-Z0-9]{1,10}$/',
                Rule::notIn(config('projects.reserved_identifiers')),
                Rule::unique('projects', 'identifier')->where(fn ($q) => $q->where('tenant_id', $workspaceId)),
            ],
            'description' => ['nullable', 'string', 'max:2000'],
            'visibility' => ['required', Rule::in(config('projects.visibilities'))],
            'lead_user_id' => [
                'nullable', 'integer',
                Rule::exists('workspace_memberships', 'user_id')
                    ->where(fn ($q) => $q->where('workspace_id', $workspaceId)->where('status', 'active')),
            ],
            'emoji' => ['nullable', 'string', 'max:16'],
            'cover_gradient' => ['nullable', 'string', 'max:200'],
        ];
    }

    public function messages(): array
    {
        return [
            'identifier.regex' => 'The ID may only contain uppercase letters and numbers.',
            'identifier.unique' => 'That project ID is already used in this workspace.',
            'identifier.not_in' => 'That project ID is reserved. Please choose another.',
            'lead_user_id.exists' => 'The lead must be a member of this workspace.',
        ];
    }
}
