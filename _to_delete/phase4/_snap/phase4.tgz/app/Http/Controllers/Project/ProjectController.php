<?php

namespace App\Http\Controllers\Project;

use App\Http\Controllers\Controller;
use App\Http\Requests\Project\StoreProjectRequest;
use App\Models\Project;
use App\Models\ProjectMember;
use App\Models\Workspace;
use App\Models\WorkspaceMembership;
use App\Services\ProjectCreator;
use App\Services\ProjectLifecycle;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Workspace → Projects: list, create, open, and lifecycle (archive/restore/delete).
 * Tenancy is initialized to the current workspace by the workspace.tenancy middleware, so
 * Project route-model bindings and queries are auto-confined to it (PRJ-002/032).
 */
class ProjectController extends Controller
{
    public function __construct(
        private readonly ProjectCreator $creator,
        private readonly ProjectLifecycle $lifecycle,
    ) {}

    private function workspace(): Workspace
    {
        return Auth::user()->currentWorkspace;
    }

    /** GET /projects */
    public function index(Request $request): View
    {
        $user = Auth::user();
        $workspace = $this->workspace();
        $archived = (bool) $request->boolean('archived');

        return view('projects.index', [
            'workspace' => $workspace,
            'user' => $user,
            'bootstrap' => [
                'projects' => $this->visibleProjects($archived ? Project::STATUS_ARCHIVED : Project::STATUS_ACTIVE),
                'archived' => $archived,
                'canCreate' => $user->can('create', [Project::class, $workspace]),
                'members' => $this->workspaceMembers(),
                'visibilities' => config('projects.visibilities'),
                'coverPresets' => config('projects.cover_presets'),
                'endpoints' => [
                    'store' => route('projects.store'),
                    'identifier' => route('projects.identifier'),
                    'list' => route('projects.index'),
                ],
            ],
        ]);
    }

    /** POST /projects */
    public function store(StoreProjectRequest $request): JsonResponse
    {
        $workspace = $this->workspace();
        abort_unless(Auth::user()->can('create', [Project::class, $workspace]), 403);

        $project = $this->creator->create($workspace, Auth::user(), $request->validated());

        return response()->json([
            'ok' => true,
            'project' => $this->card($project),
            'redirect' => route('projects.show', $project),
        ]);
    }

    /** GET /projects/identifier-available?identifier=ABC (PRJ-022 live check). */
    public function identifierAvailable(Request $request): JsonResponse
    {
        $id = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $request->query('identifier')));
        $valid = $id !== ''
            && preg_match(config('projects.identifier.regex'), $id) === 1
            && ! in_array($id, config('projects.reserved_identifiers'), true);
        $available = $valid && ! Project::query()->where('identifier', $id)->exists();

        return response()->json(['identifier' => $id, 'available' => $available]);
    }

    /** GET /projects/{project} — the project landing view (PRJ-028 post-create destination). */
    public function show(Project $project): View
    {
        abort_unless(Auth::user()->can('view', $project), 404); // 404, never leak metadata

        return view('projects.show', [
            'workspace' => $this->workspace(),
            'user' => Auth::user(),
            'project' => $this->card($project),
            'canManage' => Auth::user()->can('manage', $project),
        ]);
    }

    /** POST /projects/{project}/archive */
    public function archive(Project $project): JsonResponse
    {
        abort_unless(Auth::user()->can('manage', $project), 403);
        $this->lifecycle->archive($project);

        return response()->json(['ok' => true]);
    }

    /** POST /projects/{project}/restore */
    public function restore(Project $project): JsonResponse
    {
        abort_unless(Auth::user()->can('manage', $project), 403);
        $this->lifecycle->restore($project);

        return response()->json(['ok' => true]);
    }

    /** DELETE /projects/{project} — permanent delete with typed confirmation (PRJ-047). */
    public function destroy(Request $request, Project $project): JsonResponse
    {
        abort_unless(Auth::user()->can('delete', $project), 403);

        $confirm = strtoupper(trim((string) $request->input('confirm')));
        abort_if($confirm !== strtoupper($project->identifier), 422, 'Type the project ID to confirm deletion.');

        $this->lifecycle->delete($project);

        return response()->json(['ok' => true, 'redirect' => route('projects.index')]);
    }

    /**
     * Projects of a given status visible to the current user (PRJ-010/030/031). Owner/Admin
     * see all; others see public projects plus projects they are a member of.
     *
     * @return array<int, array<string, mixed>>
     */
    private function visibleProjects(string $status): array
    {
        $user = Auth::user();
        $wsRole = $this->workspaceRole();

        $query = Project::query()->where('status', $status)->with('lead')->latest();

        if (! in_array($wsRole, ['owner', 'admin'], true)) {
            $memberProjectIds = ProjectMember::query()->where('user_id', $user->id)->pluck('project_id');
            $query->where(function ($q) use ($memberProjectIds, $wsRole) {
                $q->whereIn('id', $memberProjectIds);
                if (in_array($wsRole, ['member', 'viewer'], true)) {
                    $q->orWhere('visibility', 'public');
                }
            });
        }

        $memberIds = ProjectMember::query()->where('user_id', $user->id)->pluck('project_id')->flip();

        return $query->limit((int) config('projects.page_size'))->get()
            ->map(fn (Project $p) => $this->card($p, $memberIds->has($p->id)))
            ->all();
    }

    /** @return array<string, mixed> */
    private function card(Project $project, ?bool $joined = null): array
    {
        $lead = $project->lead;

        return [
            'id' => $project->id,
            'name' => $project->name,
            'identifier' => $project->identifier,
            'description' => $project->description,
            'visibility' => $project->visibility,
            'emoji' => $project->emoji,
            'cover_url' => $project->cover_url,
            'cover_gradient' => $project->cover_gradient,
            'status' => $project->status,
            'lead' => $lead ? ['id' => $lead->id, 'name' => $lead->displayName(), 'initial' => $lead->initial()] : null,
            'joined' => $joined ?? ProjectMember::query()->where('project_id', $project->id)->where('user_id', Auth::id())->exists(),
            'url' => route('projects.show', $project),
            'settings_url' => route('projects.settings', ['project' => $project->id, 'section' => 'general']),
        ];
    }

    /** @return array<int, array<string, mixed>> Workspace members for the lead selector. */
    private function workspaceMembers(): array
    {
        return WorkspaceMembership::query()
            ->where('workspace_id', $this->workspace()->id)
            ->where('status', WorkspaceMembership::STATUS_ACTIVE)
            ->with('user')
            ->get()
            ->map(fn (WorkspaceMembership $m) => [
                'id' => $m->user_id,
                'name' => $m->user?->displayName(),
                'email' => $m->user?->email,
                'initial' => $m->user?->initial(),
            ])->all();
    }

    private function workspaceRole(): ?string
    {
        return WorkspaceMembership::query()
            ->where('workspace_id', $this->workspace()->id)
            ->where('user_id', Auth::id())
            ->where('status', WorkspaceMembership::STATUS_ACTIVE)
            ->value('role');
    }
}
