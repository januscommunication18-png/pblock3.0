<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

/**
 * A project inside a workspace (Phase 4). TENANT-SCOPED (CLAUDE.md §7): BelongsToTenant
 * confines every query to the active workspace and stamps tenant_id on insert. Identifier is
 * unique per workspace (UNIQUE(tenant_id, identifier)).
 */
class Project extends Model
{
    use BelongsToTenant;

    public const STATUS_ACTIVE = 'active';

    public const STATUS_ARCHIVED = 'archived';

    protected $fillable = [
        'tenant_id', 'name', 'identifier', 'description', 'visibility',
        'lead_user_id', 'cover_url', 'cover_gradient', 'emoji', 'timezone',
        'status', 'features', 'created_by', 'archived_at',
    ];

    protected function casts(): array
    {
        return [
            'features' => 'array',
            'archived_at' => 'datetime',
        ];
    }

    public function members(): HasMany
    {
        return $this->hasMany(ProjectMember::class);
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(User::class, 'lead_user_id');
    }

    public function states(): HasMany
    {
        return $this->hasMany(ProjectItemState::class);
    }

    public function labels(): HasMany
    {
        return $this->hasMany(ProjectItemLabel::class);
    }

    public function isPrivate(): bool
    {
        return $this->visibility === 'private';
    }

    public function isArchived(): bool
    {
        return $this->status === self::STATUS_ARCHIVED;
    }

    /** Effective feature toggles merged over the configured defaults. */
    public function featureFlags(): array
    {
        $defaults = collect(config('projects.features'))->map(fn ($f) => (bool) $f['default'])->all();

        return array_merge($defaults, $this->features ?? []);
    }
}
