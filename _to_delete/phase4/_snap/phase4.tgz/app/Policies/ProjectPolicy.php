<?php

namespace App\Policies;

use App\Models\Project;
use App\Models\ProjectMember;
use App\Models\User;
use App\Models\Workspace;
use App\Models\WorkspaceMembership;

/**
 * Project authorization (Phase 4 / PRJ-030/031/032). All checks are enforced server-side.
 *
 * - create: workspace Owner/Admin only (product decision for this build).
 * - view: workspace Owner/Admin see everything; a public project is visible to any active
 *   non-guest workspace member; a private project only to its explicit members.
 * - manage/delete: project admin OR workspace Owner/Admin.
 */
class ProjectPolicy
{
    /** Create a project in the given workspace — Owner/Admin only. */
    public function create(User $user, Workspace $workspace): bool
    {
        return in_array($this->workspaceRole($user, $workspace->id), ['owner', 'admin'], true);
    }

    public function view(User $user, Project $project): bool
    {
        $wsRole = $this->workspaceRole($user, $project->tenant_id);

        if ($wsRole === null) {
            return false; // not a member of the workspace at all
        }
        if (in_array($wsRole, ['owner', 'admin'], true)) {
            return true; // administrative access to every project, public or private
        }
        if ($project->isPrivate()) {
            return $this->projectRole($user, $project) !== null;
        }

        // Public project: standard workspace members (not guests) may view.
        return in_array($wsRole, ['member', 'viewer'], true);
    }

    public function manage(User $user, Project $project): bool
    {
        return in_array($this->workspaceRole($user, $project->tenant_id), ['owner', 'admin'], true)
            || $this->projectRole($user, $project) === ProjectMember::ROLE_ADMIN;
    }

    public function delete(User $user, Project $project): bool
    {
        return $this->manage($user, $project);
    }

    /** Active workspace-membership role from the central table (works without tenancy). */
    private function workspaceRole(User $user, string $workspaceId): ?string
    {
        return WorkspaceMembership::query()
            ->where('workspace_id', $workspaceId)
            ->where('user_id', $user->id)
            ->where('status', WorkspaceMembership::STATUS_ACTIVE)
            ->value('role');
    }

    private function projectRole(User $user, Project $project): ?string
    {
        return ProjectMember::query()
            ->where('project_id', $project->id)
            ->where('user_id', $user->id)
            ->value('role');
    }
}
