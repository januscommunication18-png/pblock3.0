<?php

/*
|--------------------------------------------------------------------------
| Projects (Phase 4 — Create Project)
|--------------------------------------------------------------------------
| Central source of truth for project creation, visibility, feature toggles
| and the project-settings navigation. Mirrors html/projects.html and the
| Create Project requirements doc; enforced server-side.
*/

return [
    /** Access/visibility options (PRJ-025). Default is public, matching the POC. */
    'visibilities' => ['public', 'private'],
    'default_visibility' => 'public',

    /** Project membership roles. */
    'roles' => ['admin' => 'Admin', 'member' => 'Member'],

    /** Identifier rules (PRJ-022/023): uppercase A–Z/0–9, generated from the name, ≤10 chars. */
    'identifier' => [
        'max' => 10,
        'regex' => '/^[A-Z0-9]{1,10}$/',
    ],

    /** Reserved identifiers that would collide with routes/keywords. */
    'reserved_identifiers' => ['NEW', 'CREATE', 'EDIT', 'API', 'ADMIN'],

    /** Cover upload constraints (PRJ-027). */
    'cover' => [
        'max_kb' => 5120,
        'mimes' => ['jpg', 'jpeg', 'png', 'webp', 'gif'],
    ],

    /**
     * Feature toggles surfaced in Project Settings > Features (PRJ-042). Stored on
     * projects.features; disabled features drop from project nav without deleting data.
     */
    'features' => [
        'cycles' => ['label' => 'Cycles', 'description' => 'Time-boxed sprints for planning work.', 'default' => true],
        'modules' => ['label' => 'Modules', 'description' => 'Group work items into deliverables.', 'default' => true],
        'views' => ['label' => 'Views', 'description' => 'Saved, shareable work-item views.', 'default' => true],
        'pages' => ['label' => 'Pages', 'description' => 'Docs and notes inside the project.', 'default' => true],
        'intake' => ['label' => 'Intake', 'description' => 'Triage incoming requests before they become work.', 'default' => false],
        'time_tracking' => ['label' => 'Time Tracking', 'description' => 'Log time against work items.', 'default' => false],
    ],

    /**
     * Project-settings left navigation. status: active | soon (Coming Soon).
     */
    'settings_nav' => [
        ['key' => 'general', 'label' => 'General', 'status' => 'active'],
        ['key' => 'members', 'label' => 'Members', 'status' => 'active'],
        ['key' => 'features', 'label' => 'Features', 'status' => 'active'],
        ['key' => 'states', 'label' => 'States', 'status' => 'active'],
        ['key' => 'labels', 'label' => 'Labels', 'status' => 'active'],
        ['key' => 'estimates', 'label' => 'Estimates', 'status' => 'soon'],
        ['key' => 'automations', 'label' => 'Automations', 'status' => 'soon'],
    ],

    /** Curated cover gradients offered when no image is uploaded. */
    'cover_presets' => [
        'linear-gradient(120deg,#0b0b0d 0%,#7f1d1d 55%,#0e7490 100%)',
        'linear-gradient(120deg,#1e3a8a 0%,#6d28d9 100%)',
        'linear-gradient(120deg,#065f46 0%,#0891b2 100%)',
        'linear-gradient(120deg,#9a3412 0%,#b45309 100%)',
        'linear-gradient(120deg,#334155 0%,#0f172a 100%)',
        'linear-gradient(120deg,#be123c 0%,#7c3aed 100%)',
    ],

    /** Color palette for project states/labels (reuses the settings palette). */
    'color_presets' => [
        '#F97316', '#F59E0B', '#4ADE80', '#22C55E', '#7DD3FC',
        '#2563EB', '#9CA3AF', '#DC2626', '#F78DA7', '#7C3AED',
    ],

    /** Seeded default work-item states for a new project. */
    'default_states' => [
        ['name' => 'Backlog', 'color' => '#6B7280', 'group' => 'backlog', 'is_default' => true],
        ['name' => 'Todo', 'color' => '#3B82F6', 'group' => 'unstarted', 'is_default' => false],
        ['name' => 'In Progress', 'color' => '#F97316', 'group' => 'started', 'is_default' => false],
        ['name' => 'Done', 'color' => '#22C55E', 'group' => 'completed', 'is_default' => false],
        ['name' => 'Cancelled', 'color' => '#9CA3AF', 'group' => 'cancelled', 'is_default' => false],
    ],

    'state_groups' => [
        'backlog' => 'Backlog',
        'unstarted' => 'Unstarted',
        'started' => 'Started',
        'completed' => 'Completed',
        'cancelled' => 'Cancelled',
    ],

    /** Projects-list page size (list APIs are paginated — §8 scalability). */
    'page_size' => 24,
];
