/* Projects list + Add Project modal (Phase 4). */
PB.boot('projects-index', {
  props: { bootstrap: Object },
  data: function () {
    var b = this.bootstrap;
    return {
      projects: b.projects, archived: b.archived, canCreate: b.canCreate,
      members: b.members, visibilities: b.visibilities, coverPresets: b.coverPresets,
      endpoints: b.endpoints,
      open: false, creating: false, idEdited: false, errors: {},
      form: { name: '', identifier: '', description: '', visibility: 'public', lead_user_id: '', emoji: '', cover_gradient: b.coverPresets[0] }
    };
  },
  computed: {
    leadOptions: function () {
      return [{ value: '', label: 'No lead' }].concat(this.members.map(function (m) { return { value: String(m.id), label: m.name + ' · ' + m.email }; }));
    },
    visibilityOptions: function () {
      return this.visibilities.map(function (v) { return { value: v, label: v.charAt(0).toUpperCase() + v.slice(1) }; });
    }
  },
  methods: {
    coverStyle: function (p) {
      return p.cover_url ? { backgroundImage: 'url(' + p.cover_url + ')', backgroundSize: 'cover', backgroundPosition: 'center' } : { background: p.cover_gradient || '#334155' };
    },
    openCreate: function () {
      this.errors = {}; this.idEdited = false;
      this.form = { name: '', identifier: '', description: '', visibility: 'public', lead_user_id: '', emoji: '', cover_gradient: this.coverPresets[0] };
      this.open = true;
    },
    onName: function () {
      if (this.idEdited) return;
      this.form.identifier = (this.form.name || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10);
    },
    onId: function (e) {
      this.form.identifier = (e.target.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10);
      this.idEdited = this.form.identifier.length > 0;
    },
    toggleArchived: function () {
      window.location = this.endpoints.list + (this.archived ? '' : '?archived=1');
    },
    soon: function () { this.$pb.toast('Filters & sorting are coming soon.'); },
    create: async function () {
      if (this.creating) return; this.creating = true; this.errors = {};
      var payload = Object.assign({}, this.form);
      if (!payload.lead_user_id) delete payload.lead_user_id;
      try {
        var resp = await this.$pb.api(this.endpoints.store, { method: 'POST', body: payload });
        this.$pb.toast('Project created.');
        window.location = resp.redirect;
      } catch (e) { this.errors = this.$pb.fieldErrors(e); this.$pb.toast(this.$pb.firstError(e), 'error'); }
      this.creating = false;
    }
  },
  template:
    '<div class="max-w-[1100px] mx-auto px-5 sm:px-8 py-8">' +
    '<div class="flex items-center gap-3 mb-5">' +
    '<h1 class="text-[20px] font-bold text-head">{{ archived ? \'Archived projects\' : \'Projects\' }}</h1>' +
    '<div class="ml-auto flex items-center gap-2">' +
    '<button class="h-9 px-3 rounded-md border border-line text-[13px] text-sub hover:bg-hover" @click="soon">Created date</button>' +
    '<button class="h-9 px-3 rounded-md border border-line text-[13px] text-sub hover:bg-hover" @click="soon">Filters</button>' +
    '<button class="h-9 px-3 rounded-md border border-line text-[13px] text-ink hover:bg-hover" @click="toggleArchived">{{ archived ? \'Active\' : \'Archived\' }}</button>' +
    '<button v-if="canCreate && !archived" class="h-9 px-4 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold" @click="openCreate">Add Project</button>' +
    '</div></div>' +

    // Empty state
    '<div v-if="!projects.length" class="border border-dashed border-stroke rounded-xl px-6 py-16 text-center">' +
    '<div class="text-[15px] font-semibold text-head">{{ archived ? \'No archived projects\' : \'No projects yet\' }}</div>' +
    '<p class="text-[13px] text-sub mt-1">{{ archived ? \'Archived projects will appear here.\' : \'Create your first project to get started.\' }}</p>' +
    '<button v-if="canCreate && !archived" class="mt-4 h-9 px-4 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold" @click="openCreate">Add Project</button>' +
    '</div>' +

    // Grid
    '<div v-else class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">' +
    '<a v-for="p in projects" :key="p.id" :href="p.url" class="group block border border-line rounded-xl overflow-hidden hover:shadow-md transition-shadow">' +
    '<div class="relative h-24" :style="coverStyle(p)">' +
    '<span v-if="p.emoji" class="absolute top-2.5 left-2.5 h-7 w-7 rounded-md bg-white/90 grid place-items-center text-[15px] shadow-sm">{{ p.emoji }}</span>' +
    '<span class="absolute top-2.5 right-2.5 text-[11px] bg-white/90 rounded px-1.5 py-0.5 text-sub capitalize">{{ p.visibility }}</span>' +
    '</div>' +
    '<div class="p-4">' +
    '<div class="text-[15px] font-semibold text-head truncate">{{ p.name }}</div>' +
    '<div class="text-[12px] text-sub mt-0.5">{{ p.identifier }}</div>' +
    '<div class="flex items-center gap-1.5 text-[13px] mt-3">' +
    '<template v-if="p.lead"><span class="h-5 w-5 rounded-full bg-brand text-white grid place-items-center text-[9px] font-bold">{{ p.lead.initial }}</span><span class="text-ink truncate">{{ p.lead.name }}</span></template>' +
    '<span v-else class="text-sub">No lead</span></div></div>' +
    '<div class="px-4 py-3 border-t border-line">' +
    '<span v-if="p.joined" class="inline-flex items-center text-[12px] font-medium text-green-700 bg-green-50 rounded px-2 py-0.5">Joined</span>' +
    '<span v-else class="text-[12px] text-sub">Member</span>' +
    '</div></a></div>' +

    // Add Project modal
    '<pb-modal :open="open" title="Create project" @close="open=false">' +
    '<label class="block text-[13px] font-medium text-ink mb-2">Cover</label>' +
    '<div class="flex items-center gap-2 flex-wrap mb-1">' +
    '<button v-for="g in coverPresets" :key="g" type="button" @click="form.cover_gradient=g" :style="{background:g}" :class="[\'h-8 w-12 rounded-md ring-2 ring-offset-1\', form.cover_gradient===g ? \'ring-brand\' : \'ring-transparent hover:ring-line\']"></button>' +
    '<input class="pb-input !h-8 !w-16 text-center" v-model="form.emoji" placeholder="🙂" maxlength="4" title="Emoji" />' +
    '</div>' +
    '<label class="block text-[13px] font-medium text-ink mb-1.5 mt-4">Project name <span class="text-danger">*</span></label>' +
    '<input class="pb-input" :class="{\'is-error\': errors.name}" v-model="form.name" @input="onName" placeholder="Project name" />' +
    '<p v-if="errors.name" class="text-[12px] text-danger mt-1">{{ errors.name[0] }}</p>' +
    '<label class="block text-[13px] font-medium text-ink mb-1.5 mt-4">Project ID <span class="text-danger">*</span></label>' +
    '<input class="pb-input uppercase" :class="{\'is-error\': errors.identifier}" :value="form.identifier" @input="onId" placeholder="PROJECT ID" maxlength="10" />' +
    '<p v-if="errors.identifier" class="text-[12px] text-danger mt-1">{{ errors.identifier[0] }}</p>' +
    '<label class="block text-[13px] font-medium text-ink mb-1.5 mt-4">Description</label>' +
    '<textarea class="pb-textarea" rows="2" v-model="form.description" placeholder="Optional"></textarea>' +
    '<div class="grid grid-cols-2 gap-3 mt-4">' +
    '<div><label class="block text-[13px] font-medium text-ink mb-1.5">Access</label>' +
    '<pb-combo v-model="form.visibility" :options="visibilityOptions" :searchable="false"/></div>' +
    '<div><label class="block text-[13px] font-medium text-ink mb-1.5">Lead</label>' +
    '<pb-combo v-model="form.lead_user_id" :options="leadOptions" placeholder="Search members…"/></div>' +
    '</div>' +
    '<template #footer>' +
    '<button class="h-9 px-4 rounded-md border border-stroke text-[13px] font-semibold text-ink hover:bg-hover" @click="open=false">Cancel</button>' +
    '<button class="h-9 px-4 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold disabled:opacity-50" :disabled="creating || !form.name.trim() || !form.identifier" @click="create">Create project</button>' +
    '</template></pb-modal>' +
    '</div>'
});
