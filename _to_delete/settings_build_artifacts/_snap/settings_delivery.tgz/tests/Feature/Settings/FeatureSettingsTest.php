<?php

namespace Tests\Feature\Settings;

use App\Models\CustomerProperty;
use App\Models\InitiativeLabel;
use App\Models\ReleaseTag;
use App\Models\WikiLabel;
use App\Models\WorkspaceSettings;
use Illuminate\Foundation\Testing\RefreshDatabase;

/** Wiki, Releases, Initiatives, Customers, Teamspaces (spec §7-§11). */
class FeatureSettingsTest extends SettingsTestCase
{
    use RefreshDatabase;

    public function test_wiki_toggle_info_and_labels(): void
    {
        [$owner, $workspace] = $this->owner();

        $this->actingAs($owner)->postJson(route('settings.wiki.toggle'), ['enabled' => false])->assertOk();
        $this->actingAs($owner)->patchJson(route('settings.wiki.info'), [
            'wiki_description' => 'Team knowledge base', 'wiki_docs_url' => 'https://docs.example.com',
        ])->assertOk();
        $this->actingAs($owner)->postJson(route('settings.wiki.labels.store'), ['name' => 'Guide', 'color' => '#22C55E'])->assertOk();

        $settings = $workspace->run(fn () => WorkspaceSettings::first());
        $this->assertFalse($settings->wiki_enabled);
        $this->assertSame('Team knowledge base', $settings->wiki_description);
        $this->assertTrue($workspace->run(fn () => WikiLabel::where('name', 'Guide')->exists()));
    }

    public function test_releases_toggle_tag_and_label(): void
    {
        [$owner, $workspace] = $this->owner();

        $this->actingAs($owner)->postJson(route('settings.releases.tags.store'), ['name' => 'v1.0.0'])
            ->assertOk()->assertJsonPath('tags.0.name', 'v1.0.0');
        $this->actingAs($owner)->postJson(route('settings.releases.labels.store'), ['name' => 'Hotfix', 'color' => '#DC2626'])->assertOk();

        $this->assertTrue($workspace->run(fn () => ReleaseTag::where('name', 'v1.0.0')->exists()));
    }

    public function test_initiative_labels_are_locked_until_enabled(): void
    {
        [$owner, $workspace] = $this->owner();

        // Default off → label writes rejected (spec §9).
        $this->actingAs($owner)->postJson(route('settings.initiatives.labels.store'), ['name' => 'Q3', 'color' => '#2563EB'])
            ->assertStatus(422);
        $this->assertSame(0, $workspace->run(fn () => InitiativeLabel::count()));

        // Enable, then it succeeds.
        $this->actingAs($owner)->postJson(route('settings.initiatives.toggle'), ['enabled' => true])->assertOk();
        $this->actingAs($owner)->postJson(route('settings.initiatives.labels.store'), ['name' => 'Q3', 'color' => '#2563EB'])->assertOk();
        $this->assertSame(1, $workspace->run(fn () => InitiativeLabel::count()));
    }

    public function test_customers_toggle_and_property_crud_with_dropdown_options(): void
    {
        [$owner, $workspace] = $this->owner();

        $this->actingAs($owner)->postJson(route('settings.customers.properties.store'), [
            'title' => 'Tier', 'type' => 'Dropdown', 'mandatory' => true, 'active' => true,
            'options' => ['Gold', 'Silver', 'Bronze'],
        ])->assertOk();

        $prop = $workspace->run(fn () => CustomerProperty::first());
        $this->assertSame('Tier', $prop->title);
        $this->assertTrue($prop->mandatory);
        $this->assertSame(['Gold', 'Silver', 'Bronze'], $prop->options);
    }

    public function test_dropdown_property_requires_options(): void
    {
        [$owner] = $this->owner();

        $this->actingAs($owner)->postJson(route('settings.customers.properties.store'), [
            'title' => 'Tier', 'type' => 'Dropdown',
        ])->assertStatus(422)->assertJsonValidationErrors('options');
    }

    public function test_teamspaces_enable_is_one_way(): void
    {
        [$owner, $workspace] = $this->owner();

        $this->actingAs($owner)->postJson(route('settings.teamspaces.toggle'), ['enabled' => true])
            ->assertOk()->assertJsonPath('locked', true);

        // A later disable request is rejected (spec §10).
        $this->actingAs($owner)->postJson(route('settings.teamspaces.toggle'), ['enabled' => false])
            ->assertStatus(422);

        $this->assertTrue($workspace->run(fn () => WorkspaceSettings::first()->teamspaces_enabled));
    }
}
