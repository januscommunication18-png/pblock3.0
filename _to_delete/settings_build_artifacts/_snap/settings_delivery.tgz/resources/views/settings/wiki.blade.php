@extends('settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/settings/wiki.js') }}"></script>
@endpush
