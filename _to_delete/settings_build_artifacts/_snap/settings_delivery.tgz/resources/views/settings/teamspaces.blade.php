@extends('settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/settings/teamspaces.js') }}"></script>
@endpush
