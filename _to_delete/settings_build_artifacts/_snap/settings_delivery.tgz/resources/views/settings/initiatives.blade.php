@extends('settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/settings/initiatives.js') }}"></script>
@endpush
