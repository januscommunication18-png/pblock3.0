@extends('settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/settings/releases.js') }}"></script>
@endpush
