@extends('settings.layout')

@push('section-script')
  <script defer src="{{ asset('assets/js/settings/members.js') }}"></script>
@endpush
