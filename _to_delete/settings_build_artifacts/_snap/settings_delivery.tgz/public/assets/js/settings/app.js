/* Project Block — Workspace Settings shared Vue runtime + components.
   ------------------------------------------------------------------
   Hybrid Vue-in-Blade (CLAUDE.md §14), no FlyonUI. Loaded on every settings
   page; each section script calls PB.boot('<section>', Component) to mount its
   Vue component on #settings-root, receiving the server `bootstrap` prop.
   Styling uses the shared POC tokens + .pb-* form classes (public/assets).
   Authored with the Options API so components map 1:1 to future .vue SFCs.
   ------------------------------------------------------------------ */
(function () {
  'use strict';

  var CSRF = (document.querySelector('meta[name=csrf-token]') || {}).content || '';

  // ---- fetch helper: JSON in/out, CSRF, throws {status,data} on failure ----
  async function api(url, opts) {
    opts = opts || {};
    var headers = { 'X-CSRF-TOKEN': CSRF, Accept: 'application/json' };
    var body = opts.body;
    if (body && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(body);
    }
    var res = await fetch(url, { method: opts.method || 'GET', headers: headers, body: body });
    var data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) { var err = new Error('Request failed'); err.status = res.status; err.data = data; throw err; }
    return data;
  }

  // Replace the '__ID__' placeholder in a templated endpoint with a real id.
  function withId(url, id) { return String(url).replace('__ID__', encodeURIComponent(id)); }

  // First validation message from a 422 response, else a generic message.
  function firstError(err, fallback) {
    var d = err && err.data;
    if (d && d.errors) { for (var k in d.errors) { return d.errors[k][0]; } }
    if (d && d.message) return d.message;
    return fallback || 'Something went wrong. Please try again.';
  }

  // ---- lightweight toast ----
  function toast(message, kind) {
    var el = document.createElement('div');
    el.className = 'fixed bottom-5 right-5 z-[90] flex items-start gap-3 bg-white border border-line shadow-lg rounded-lg px-4 py-3 max-w-[340px]';
    var dot = kind === 'error' ? '#ef4444' : '#22c55e';
    el.innerHTML = '<span class="mt-0.5 h-4 w-4 rounded-full shrink-0" style="background:' + dot + '"></span>' +
      '<div class="text-[13px] text-ink"></div>';
    el.querySelector('div').textContent = message;
    document.body.appendChild(el);
    setTimeout(function () { el.style.transition = 'opacity .4s'; el.style.opacity = '0'; setTimeout(function () { el.remove(); }, 400); }, 3200);
  }

  // ================= shared components =================
  function registerShared(app) {
    // Feature on/off switch.
    app.component('pb-toggle', {
      props: { modelValue: Boolean, disabled: Boolean },
      emits: ['update:modelValue'],
      template:
        '<button type="button" @click="!disabled && $emit(\'update:modelValue\', !modelValue)"' +
        ' :aria-pressed="String(modelValue)"' +
        ' :class="[\'relative inline-flex h-6 w-11 items-center rounded-full transition-colors shrink-0\',' +
        ' modelValue ? \'bg-brand\' : \'bg-stroke\', disabled ? \'opacity-50 cursor-not-allowed\' : \'cursor-pointer\']">' +
        '<span :class="[\'inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform\',' +
        ' modelValue ? \'translate-x-[22px]\' : \'translate-x-0.5\']"></span></button>'
    });

    // Preset palette + hex entry (spec §13).
    app.component('pb-color-picker', {
      props: { modelValue: { type: String, default: '#F97316' }, presets: { type: Array, default: function () { return []; } } },
      emits: ['update:modelValue'],
      methods: {
        pick: function (c) { this.$emit('update:modelValue', c); },
        onHex: function (e) {
          var v = e.target.value.trim();
          if (v && v[0] !== '#') v = '#' + v;
          this.$emit('update:modelValue', v.toUpperCase());
        },
        same: function (c) { return (this.modelValue || '').toUpperCase() === c.toUpperCase(); }
      },
      template:
        '<div class="flex items-center gap-2 flex-wrap">' +
        '<button v-for="c in presets" :key="c" type="button" @click="pick(c)" :style="{background:c}"' +
        ' :class="[\'h-6 w-6 rounded-full ring-2 ring-offset-1\', same(c) ? \'ring-brand\' : \'ring-transparent hover:ring-line\']"></button>' +
        '<div class="pb-group !h-9" style="width:8.5rem">' +
        '<span class="pb-group__prefix"><span class="inline-block h-3 w-3 rounded-full align-middle" :style="{background:modelValue}"></span></span>' +
        '<input class="pb-group__field uppercase" :value="modelValue" @input="onHex" maxlength="7" spellcheck="false" /></div></div>'
    });

    // Centered modal dialog.
    app.component('pb-modal', {
      props: { open: Boolean, title: String },
      emits: ['close'],
      template:
        '<teleport to="body"><div v-if="open" class="fixed inset-0 z-[70] flex items-start justify-center p-4 sm:pt-24">' +
        '<div class="absolute inset-0 bg-black/40" @click="$emit(\'close\')"></div>' +
        '<div class="relative w-full max-w-[520px] bg-white rounded-xl shadow-xl flex flex-col max-h-[85vh]">' +
        '<div class="flex items-center justify-between px-6 py-4 border-b border-line shrink-0">' +
        '<h2 class="text-[16px] font-semibold text-head">{{ title }}</h2>' +
        '<button @click="$emit(\'close\')" class="h-8 w-8 grid place-items-center rounded-md text-sub hover:bg-hover">' +
        '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button></div>' +
        '<div class="px-6 py-5 overflow-y-auto"><slot/></div>' +
        '<div class="px-6 py-4 border-t border-line flex justify-end gap-2 shrink-0"><slot name="footer"/></div>' +
        '</div></div></teleport>'
    });

    // Destructive confirmation.
    app.component('pb-confirm', {
      props: { open: Boolean, title: String, message: String, confirmLabel: { type: String, default: 'Delete' } },
      emits: ['confirm', 'close'],
      template:
        '<pb-modal :open="open" :title="title" @close="$emit(\'close\')">' +
        '<p class="text-[13px] text-sub leading-relaxed">{{ message }}</p>' +
        '<template #footer>' +
        '<button class="h-9 px-4 rounded-md border border-stroke text-[13px] font-semibold text-ink hover:bg-hover" @click="$emit(\'close\')">Cancel</button>' +
        '<button class="h-9 px-4 rounded-md bg-danger text-white text-[13px] font-semibold hover:opacity-90" @click="$emit(\'confirm\')">{{ confirmLabel }}</button>' +
        '</template></pb-modal>'
    });

    // Empty state card with a primary action slot (spec §13).
    app.component('pb-empty', {
      props: { title: String, subtitle: String },
      template:
        '<div class="border border-dashed border-stroke rounded-xl px-6 py-10 text-center">' +
        '<div class="text-[14px] font-medium text-head">{{ title }}</div>' +
        '<p class="text-[13px] text-sub mt-1 max-w-md mx-auto">{{ subtitle }}</p>' +
        '<div class="mt-4 flex justify-center"><slot/></div></div>'
    });

    // Section title + description block.
    app.component('pb-section-head', {
      props: { title: String, desc: String },
      template:
        '<div class="mb-5"><h1 class="text-[20px] font-bold text-head">{{ title }}</h1>' +
        '<p v-if="desc" class="text-[13px] text-sub mt-1 max-w-2xl">{{ desc }}</p></div>'
    });

    // A colored label/tag chip row with edit/delete actions.
    app.component('pb-label-row', {
      props: { name: String, color: String },
      emits: ['edit', 'remove'],
      template:
        '<div class="flex items-center gap-3 px-3 py-2.5 border border-line rounded-lg">' +
        '<span class="h-3.5 w-3.5 rounded-full shrink-0" :style="{background: color || \'#9ca3af\'}"></span>' +
        '<span class="text-[13px] text-ink flex-1 truncate">{{ name }}</span>' +
        '<button class="text-[12px] text-sub hover:text-ink px-1.5" @click="$emit(\'edit\')">Edit</button>' +
        '<button class="text-[12px] text-danger hover:opacity-80 px-1.5" @click="$emit(\'remove\')">Delete</button>' +
        '</div>'
    });

    // Self-contained CRUD manager for a color label / tag list. Reused by Projects, Wiki,
    // Releases (labels + tags) and Initiatives. Talks to the server directly and refreshes
    // from the returned collection.
    app.component('pb-label-manager', {
      props: {
        title: String, description: String,
        items: { type: Array, default: function () { return []; } },
        presets: { type: Array, default: function () { return []; } },
        storeUrl: String, itemUrl: String,
        collectionKey: { type: String, default: 'labels' },
        singular: { type: String, default: 'label' },
        addText: { type: String, default: 'Add label' },
        namePlaceholder: { type: String, default: 'Label name' },
        emptyTitle: { type: String, default: 'No labels yet' },
        emptySubtitle: { type: String, default: 'Create your first label to get started.' },
        withColor: { type: Boolean, default: true },
        disabled: { type: Boolean, default: false },
        lockedTitle: String, lockedSubtitle: String
      },
      data: function () {
        return { list: this.items.slice(), open: false, editing: null, saving: false,
          form: { name: '', color: this.presets[0] || '#F97316' }, confirm: { open: false, item: null } };
      },
      methods: {
        openAdd: function () { this.editing = null; this.form = { name: '', color: this.presets[0] || '#F97316' }; this.open = true; },
        openEdit: function (it) { this.editing = it; this.form = { name: it.name, color: it.color || this.presets[0] || '#F97316' }; this.open = true; },
        close: function () { this.open = false; },
        save: async function () {
          if (!this.form.name.trim() || this.saving) return;
          this.saving = true;
          var payload = { name: this.form.name.trim() };
          if (this.withColor) payload.color = this.form.color;
          try {
            var url = this.editing ? this.$pb.withId(this.itemUrl, this.editing.id) : this.storeUrl;
            var resp = await this.$pb.api(url, { method: this.editing ? 'PATCH' : 'POST', body: payload });
            this.list = resp[this.collectionKey] || this.list;
            this.open = false;
            this.$pb.toast(this.editing ? 'Updated.' : 'Added.');
          } catch (e) { this.$pb.toast(this.$pb.firstError(e), 'error'); }
          this.saving = false;
        },
        askRemove: function (it) { this.confirm = { open: true, item: it }; },
        remove: async function () {
          var it = this.confirm.item; if (!it) return;
          try {
            var resp = await this.$pb.api(this.$pb.withId(this.itemUrl, it.id), { method: 'DELETE' });
            this.list = resp[this.collectionKey] || this.list;
            this.$pb.toast('Deleted.');
          } catch (e) { this.$pb.toast(this.$pb.firstError(e), 'error'); }
          this.confirm = { open: false, item: null };
        }
      },
      template:
        '<div>' +
        '<div class="flex items-start justify-between gap-4 mb-3">' +
        '<div><h2 class="text-[15px] font-semibold text-head">{{ title }}</h2>' +
        '<p v-if="description" class="text-[12px] text-sub mt-0.5 max-w-xl">{{ description }}</p></div>' +
        '<button v-if="!disabled" class="h-9 px-3.5 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold shrink-0" @click="openAdd">{{ addText }}</button>' +
        '</div>' +
        '<div v-if="disabled" class="border border-dashed border-stroke rounded-xl px-6 py-10 text-center">' +
        '<div class="text-[14px] font-medium text-head">{{ lockedTitle }}</div>' +
        '<p class="text-[13px] text-sub mt-1 max-w-md mx-auto">{{ lockedSubtitle }}</p></div>' +
        '<template v-else>' +
        '<pb-empty v-if="!list.length" :title="emptyTitle" :subtitle="emptySubtitle">' +
        '<button class="h-9 px-4 rounded-md border border-stroke text-[13px] font-semibold text-ink hover:bg-hover" @click="openAdd">{{ addText }}</button></pb-empty>' +
        '<div v-else class="space-y-2">' +
        '<pb-label-row v-for="it in list" :key="it.id" :name="it.name" :color="it.color" @edit="openEdit(it)" @remove="askRemove(it)"/>' +
        '</div></template>' +
        '<pb-modal :open="open" :title="(editing ? \'Edit \' : \'Add \') + singular" @close="close">' +
        '<label class="block text-[13px] font-medium text-ink mb-1.5">Name</label>' +
        '<input class="pb-input" v-model="form.name" :placeholder="namePlaceholder" @keyup.enter="save" />' +
        '<div v-if="withColor" class="mt-4"><label class="block text-[13px] font-medium text-ink mb-2">Color</label>' +
        '<pb-color-picker v-model="form.color" :presets="presets" /></div>' +
        '<template #footer>' +
        '<button class="h-9 px-4 rounded-md border border-stroke text-[13px] font-semibold text-ink hover:bg-hover" @click="close">Cancel</button>' +
        '<button class="h-9 px-4 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold disabled:opacity-50" :disabled="saving || !form.name.trim()" @click="save">{{ editing ? \'Save\' : \'Add\' }}</button>' +
        '</template></pb-modal>' +
        '<pb-confirm :open="confirm.open" :title="\'Delete \' + singular + \'?\'" :message="\'This removes it from the workspace. This action cannot be undone.\'" @close="confirm.open=false" @confirm="remove" />' +
        '</div>'
    });
  }

  // ================= boot =================
  function boot(name, component) {
    var root = document.getElementById('settings-root');
    if (!root || !window.Vue) return;
    var bootstrap = {};
    try { bootstrap = JSON.parse(root.getAttribute('data-bootstrap') || '{}'); } catch (e) {}
    var app = Vue.createApp(component, { bootstrap: bootstrap });
    app.config.globalProperties.$pb = { api: api, withId: withId, firstError: firstError, toast: toast };
    registerShared(app);
    root.innerHTML = '';
    app.mount(root);
  }

  window.PB = { api: api, withId: withId, firstError: firstError, toast: toast, boot: boot };
})();
