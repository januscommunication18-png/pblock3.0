/* Settings › Members — People + Pending Invites, invite/role/remove/revoke (spec §5). */
PB.boot('members', {
  props: { bootstrap: Object },
  data: function () {
    var b = this.bootstrap;
    return {
      tab: 'people',
      people: b.people, pending: b.pending,
      roleLabels: b.roleLabels, inviteRoles: b.inviteRoles,
      currentUserId: b.currentUserId, endpoints: b.endpoints,
      search: '',
      inviteOpen: false, sending: false,
      invites: [{ email: '', role: 'member' }],
      remove: { open: false, member: null }
    };
  },
  computed: {
    filteredPeople: function () {
      var q = this.search.trim().toLowerCase();
      if (!q) return this.people;
      return this.people.filter(function (p) {
        return (p.name || '').toLowerCase().indexOf(q) >= 0 || (p.email || '').toLowerCase().indexOf(q) >= 0;
      });
    }
  },
  methods: {
    roleLabel: function (r) { return this.roleLabels[r] || r; },
    addRow: function () { this.invites.push({ email: '', role: 'member' }); },
    dropRow: function (i) { this.invites.splice(i, 1); if (!this.invites.length) this.addRow(); },
    openInvite: function () { this.invites = [{ email: '', role: 'member' }]; this.inviteOpen = true; },
    sendInvites: async function () {
      if (this.sending) return; this.sending = true;
      var rows = this.invites.filter(function (r) { return r.email.trim(); });
      try {
        var resp = await this.$pb.api(this.endpoints.invite, { method: 'POST', body: { invites: rows } });
        this.pending = resp.pending; this.inviteOpen = false; this.tab = 'pending';
        this.$pb.toast(resp.sent + ' invitation' + (resp.sent === 1 ? '' : 's') + ' sent.');
      } catch (e) { this.$pb.toast(this.$pb.firstError(e), 'error'); }
      this.sending = false;
    },
    changeRole: async function (m, role) {
      try {
        var resp = await this.$pb.api(this.$pb.withId(this.endpoints.role, m.id), { method: 'PATCH', body: { role: role } });
        this.people = resp.people; this.$pb.toast('Role updated.');
      } catch (e) { this.$pb.toast(this.$pb.firstError(e), 'error'); }
    },
    askRemove: function (m) { this.remove = { open: true, member: m }; },
    doRemove: async function () {
      var m = this.remove.member; if (!m) return;
      try {
        var resp = await this.$pb.api(this.$pb.withId(this.endpoints.remove, m.id), { method: 'DELETE' });
        this.people = resp.people; this.$pb.toast('Member removed.');
      } catch (e) { this.$pb.toast(this.$pb.firstError(e), 'error'); }
      this.remove = { open: false, member: null };
    },
    revoke: async function (inv) {
      try {
        var resp = await this.$pb.api(this.$pb.withId(this.endpoints.revoke, inv.id), { method: 'DELETE' });
        this.pending = resp.pending; this.$pb.toast('Invitation revoked.');
      } catch (e) { this.$pb.toast(this.$pb.firstError(e), 'error'); }
    }
  },
  template:
    '<div class="max-w-[980px] mx-auto px-5 sm:px-8 py-8">' +
    '<div class="flex items-start justify-between gap-4">' +
    '<pb-section-head title="Members" desc="Manage access to this workspace."/>' +
    '<button class="h-9 px-4 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold shrink-0" @click="openInvite">Add member</button>' +
    '</div>' +

    // Tabs
    '<div class="flex items-center gap-1 border-b border-line mb-4">' +
    '<button :class="[\'px-3 h-9 text-[13px] -mb-px border-b-2\', tab===\'people\' ? \'border-brand text-brand font-medium\' : \'border-transparent text-sub hover:text-ink\']" @click="tab=\'people\'">People</button>' +
    '<button :class="[\'px-3 h-9 text-[13px] -mb-px border-b-2\', tab===\'pending\' ? \'border-brand text-brand font-medium\' : \'border-transparent text-sub hover:text-ink\']" @click="tab=\'pending\'">Pending Invites <span v-if="pending.length" class="ml-1 text-[11px] bg-hover text-sub rounded px-1.5 py-0.5">{{ pending.length }}</span></button>' +
    '</div>' +

    // People
    '<div v-if="tab===\'people\'">' +
    '<div class="mb-3 relative max-w-xs">' +
    '<input class="pb-input !h-9" placeholder="Search…" v-model="search"/></div>' +
    '<div class="border border-line rounded-xl overflow-hidden">' +
    '<table class="w-full text-[13px]"><thead class="bg-[#f8f9fa] text-sub"><tr>' +
    '<th class="text-left font-medium px-4 py-2.5">Name</th>' +
    '<th class="text-left font-medium px-4 py-2.5 hidden md:table-cell">Role</th>' +
    '<th class="text-left font-medium px-4 py-2.5 hidden lg:table-cell">Billing</th>' +
    '<th class="text-left font-medium px-4 py-2.5 hidden lg:table-cell">Auth</th>' +
    '<th class="text-left font-medium px-4 py-2.5 hidden xl:table-cell">Joined</th>' +
    '<th class="px-4 py-2.5"></th></tr></thead>' +
    '<tbody class="divide-y divide-line">' +
    '<tr v-for="p in filteredPeople" :key="p.id" class="hover:bg-hover/50">' +
    '<td class="px-4 py-2.5"><div class="flex items-center gap-2.5">' +
    '<span class="h-7 w-7 rounded-full bg-emerald-500 text-white grid place-items-center text-[11px] font-bold shrink-0">{{ p.initial }}</span>' +
    '<div class="min-w-0"><div class="text-ink font-medium truncate">{{ p.name }}<span v-if="p.user_id===currentUserId" class="text-[11px] text-faint font-normal"> (You)</span></div>' +
    '<div class="text-faint text-[12px] truncate">{{ p.email }}</div></div></div></td>' +
    '<td class="px-4 py-2.5 hidden md:table-cell">' +
    '<span v-if="p.is_owner" class="text-[12px] bg-sel text-brand rounded px-2 py-0.5">Owner</span>' +
    '<select v-else class="pb-input !h-8 !w-28 text-[12px]" :value="p.role" @change="changeRole(p, $event.target.value)">' +
    '<option v-for="r in inviteRoles" :key="r" :value="r">{{ roleLabel(r) }}</option></select></td>' +
    '<td class="px-4 py-2.5 hidden lg:table-cell text-sub">{{ p.billing }}</td>' +
    '<td class="px-4 py-2.5 hidden lg:table-cell text-sub">{{ p.auth }}</td>' +
    '<td class="px-4 py-2.5 hidden xl:table-cell text-sub">{{ p.joined }}</td>' +
    '<td class="px-4 py-2.5 text-right">' +
    '<button v-if="!p.is_owner" class="text-[12px] text-danger hover:opacity-80" @click="askRemove(p)">Delete</button></td>' +
    '</tr>' +
    '<tr v-if="!filteredPeople.length"><td colspan="6" class="px-4 py-8 text-center text-sub">No members match your search.</td></tr>' +
    '</tbody></table></div></div>' +

    // Pending
    '<div v-else>' +
    '<pb-empty v-if="!pending.length" title="No pending invites" subtitle="Invitations you send will appear here until they are accepted.">' +
    '<button class="h-9 px-4 rounded-md border border-stroke text-[13px] font-semibold text-ink hover:bg-hover" @click="openInvite">Add member</button></pb-empty>' +
    '<div v-else class="border border-line rounded-xl overflow-hidden">' +
    '<table class="w-full text-[13px]"><thead class="bg-[#f8f9fa] text-sub"><tr>' +
    '<th class="text-left font-medium px-4 py-2.5">Email</th>' +
    '<th class="text-left font-medium px-4 py-2.5">Role</th>' +
    '<th class="text-left font-medium px-4 py-2.5 hidden md:table-cell">Invited</th>' +
    '<th class="text-left font-medium px-4 py-2.5 hidden md:table-cell">Invited by</th>' +
    '<th class="px-4 py-2.5"></th></tr></thead>' +
    '<tbody class="divide-y divide-line">' +
    '<tr v-for="inv in pending" :key="inv.id">' +
    '<td class="px-4 py-2.5 text-ink">{{ inv.email }}</td>' +
    '<td class="px-4 py-2.5"><span class="text-[12px] bg-hover text-sub rounded px-2 py-0.5">{{ roleLabel(inv.role) }}</span></td>' +
    '<td class="px-4 py-2.5 text-sub hidden md:table-cell">{{ inv.invited }}</td>' +
    '<td class="px-4 py-2.5 text-sub hidden md:table-cell">{{ inv.by }}</td>' +
    '<td class="px-4 py-2.5 text-right"><button class="text-[12px] text-danger hover:opacity-80" @click="revoke(inv)">Revoke</button></td>' +
    '</tr></tbody></table></div></div>' +

    // Invite modal
    '<pb-modal :open="inviteOpen" title="Invite people to collaborate" @close="inviteOpen=false">' +
    '<p class="text-[13px] text-sub mb-3">Invite people to collaborate on your workspace.</p>' +
    '<div class="space-y-2">' +
    '<div v-for="(row,i) in invites" :key="i" class="flex items-center gap-2">' +
    '<input class="pb-input !h-9 flex-1" placeholder="name@company.com" v-model="row.email"/>' +
    '<select class="pb-input !h-9 !w-28" v-model="row.role"><option v-for="r in inviteRoles" :key="r" :value="r">{{ roleLabel(r) }}</option></select>' +
    '<button class="h-9 w-9 grid place-items-center rounded-md text-sub hover:bg-hover" @click="dropRow(i)" title="Remove">' +
    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>' +
    '</div></div>' +
    '<button class="text-[13px] text-link font-medium mt-3" @click="addRow">+ Add more</button>' +
    '<template #footer>' +
    '<button class="h-9 px-4 rounded-md border border-stroke text-[13px] font-semibold text-ink hover:bg-hover" @click="inviteOpen=false">Cancel</button>' +
    '<button class="h-9 px-4 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold disabled:opacity-50" :disabled="sending" @click="sendInvites">Send invitations</button>' +
    '</template></pb-modal>' +

    '<pb-confirm :open="remove.open" title="Remove member?" :message="(remove.member ? remove.member.name : \'\') + \' will lose access to this workspace. Authored records are preserved.\'" confirm-label="Remove" @close="remove.open=false" @confirm="doRemove"/>' +
    '</div>'
});
