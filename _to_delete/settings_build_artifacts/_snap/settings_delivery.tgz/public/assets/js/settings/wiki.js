/* Settings › Wiki — enable, description + docs link, wiki labels (spec §7). */
PB.boot('wiki', {
  props: { bootstrap: Object },
  data: function () {
    var b = this.bootstrap;
    return {
      enabled: b.enabled,
      info: { wiki_description: b.description || '', wiki_docs_url: b.docsUrl || '' },
      labels: b.labels, presets: b.color.presets, endpoints: b.endpoints, savingInfo: false
    };
  },
  methods: {
    toggle: async function (v) {
      this.enabled = v;
      try { await this.$pb.api(this.endpoints.toggle, { method: 'POST', body: { enabled: v } }); this.$pb.toast('Saved.'); }
      catch (e) { this.enabled = !v; this.$pb.toast(this.$pb.firstError(e), 'error'); }
    },
    saveInfo: async function () {
      if (this.savingInfo) return; this.savingInfo = true;
      try { await this.$pb.api(this.endpoints.info, { method: 'PATCH', body: this.info }); this.$pb.toast('Saved.'); }
      catch (e) { this.$pb.toast(this.$pb.firstError(e), 'error'); }
      this.savingInfo = false;
    }
  },
  template:
    '<div class="max-w-[820px] mx-auto px-5 sm:px-8 py-8">' +
    '<pb-section-head title="Wiki" desc="A living knowledge base for your team. Write docs, capture decisions, and keep context close to the work that needs it."/>' +

    '<div class="flex items-center justify-between gap-4 border border-line rounded-xl px-4 py-3 mb-5">' +
    '<div><div class="text-[14px] font-medium text-ink">Turn on wiki for this workspace</div>' +
    '<p class="text-[12px] text-sub mt-0.5">Manage workspace-level wiki access and page organization.</p></div>' +
    '<pb-toggle :model-value="enabled" @update:model-value="toggle"/></div>' +

    '<div :class="{\'opacity-50 pointer-events-none\': !enabled}">' +
    '<div class="border border-line rounded-xl p-5 mb-5">' +
    '<label class="block text-[13px] font-medium text-ink mb-1.5">Description</label>' +
    '<textarea class="pb-textarea" rows="3" v-model="info.wiki_description" placeholder="Describe what this wiki is for…"></textarea>' +
    '<label class="block text-[13px] font-medium text-ink mb-1.5 mt-4">Docs link</label>' +
    '<input class="pb-input" v-model="info.wiki_docs_url" placeholder="https://…"/>' +
    '<div class="mt-4"><button class="h-9 px-4 rounded-md bg-brand hover:bg-brand-dark text-white text-[13px] font-semibold disabled:opacity-50" :disabled="savingInfo" @click="saveInfo">Save</button></div>' +
    '</div>' +

    '<pb-label-manager title="Labels" description="Organize pages with custom labels to make information easier to group, discover, and manage across your workspace." ' +
    ':items="labels" :presets="presets" :store-url="endpoints.labels" :item-url="endpoints.label" ' +
    'empty-title="No labels yet" empty-subtitle="Create your first label to get started."/>' +
    '</div></div>'
});
