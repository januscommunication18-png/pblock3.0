<?php

namespace App\Http\Controllers\Settings;

use App\Http\Requests\Settings\UpdateWorkspaceGeneralRequest;
use App\Http\Requests\Settings\UploadWorkspaceLogoRequest;
use App\Services\WorkspaceDeleter;
use DateTimeZone;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

/**
 * Administration > General (spec §4). Workspace identity + danger-zone deletion.
 */
class GeneralSettingsController extends SettingsController
{
    /** GET /settings/general */
    public function show(): View
    {
        $this->guardManage();
        $w = $this->workspace();

        return $this->page('general', [
            'workspace' => [
                'name' => $w->name,
                'slug' => $w->slug,
                'company_size' => $w->company_size,
                'timezone' => $w->timezone,
                'logo_url' => $w->logo_url,
                'initial' => $w->initial(),
            ],
            'urlPrefix' => 'app.projectblock.so/',
            'teamSizes' => config('workspace.team_sizes'),
            'timezones' => DateTimeZone::listIdentifiers(),
            'canDelete' => Auth::user()->can('delete', $w),
            'endpoints' => [
                'update' => route('settings.general.update'),
                'logo' => route('settings.general.logo'),
                'delete' => route('settings.general.destroy'),
            ],
        ]);
    }

    /** PATCH /settings/general */
    public function update(UpdateWorkspaceGeneralRequest $request): JsonResponse
    {
        $this->guardManage();
        $w = $this->workspace();

        $w->forceFill([
            'name' => $request->validated('name'),
            'company_size' => $request->validated('company_size'),
            'slug' => $request->validated('slug'),
            'timezone' => $request->validated('timezone'),
        ])->save();

        return response()->json([
            'ok' => true,
            'workspace' => [
                'name' => $w->name,
                'slug' => $w->slug,
                'company_size' => $w->company_size,
                'timezone' => $w->timezone,
                'initial' => $w->initial(),
            ],
        ]);
    }

    /** POST /settings/general/logo */
    public function logo(UploadWorkspaceLogoRequest $request): JsonResponse
    {
        $this->guardManage();
        $w = $this->workspace();

        $path = $request->file('logo')->store("workspace-logos/{$w->id}", 'public');
        $w->forceFill(['logo_url' => Storage::disk('public')->url($path)])->save();

        return response()->json(['ok' => true, 'logo_url' => $w->logo_url]);
    }

    /** DELETE /settings/general — owner only (SET-G-008). */
    public function destroy(WorkspaceDeleter $deleter): RedirectResponse
    {
        $w = $this->workspace();
        abort_unless(Auth::user()->can('delete', $w), 403);

        $name = $w->name;
        $deleter->delete($w);

        return redirect()->route('welcome')->with('status', "Workspace \"{$name}\" deleted.");
    }
}
