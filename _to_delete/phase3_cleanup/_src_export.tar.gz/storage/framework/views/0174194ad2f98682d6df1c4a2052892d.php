<?php $__env->startSection('title', 'Sign in — Project Block'); ?>

<?php $startStep2 = $errors->any() && old('email'); ?>

<?php $__env->startSection('body'); ?>
  <header class="flex items-center justify-between px-5 sm:px-10 py-6">
    <a class="flex items-center gap-2" href="<?php echo e(route('signup')); ?>">
      <svg width="26" height="26" viewBox="0 0 32 32" fill="#0f0f10" aria-hidden="true">
        <path d="M5 21 L15 4 L20.5 4 L10.5 21 Z" /><path d="M13 28 L23 11 L28.5 11 L18.5 28 Z" />
      </svg>
      <span class="text-[20px] font-bold tracking-tight text-head">Project Block</span>
    </a>
    <p class="text-[13px] text-sub">
      New to Project Block?
      <a href="<?php echo e(route('signup')); ?>" class="text-link font-semibold hover:underline">Sign up</a>
    </p>
  </header>

  <main class="flex-1 flex justify-center px-5">
    <div class="w-full max-w-[380px] pt-6 sm:pt-10">
      <h1 class="text-[24px] font-bold text-head leading-tight">Work in all dimensions.</h1>
      <p class="text-[18px] text-sub mb-7">Welcome back to Project Block.</p>

      <?php if($errors->any()): ?>
        <div class="mb-4 rounded-lg border border-danger/40 bg-danger/5 px-3.5 py-2.5 text-[13px] text-danger"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>
      <?php if(session('status')): ?>
        <div class="mb-4 rounded-lg border border-brand/30 bg-brand/5 px-3.5 py-2.5 text-[13px] text-brand"><?php echo e(session('status')); ?></div>
      <?php endif; ?>

      
      <div class="space-y-3">
        <a href="<?php echo e(route('social.redirect', 'google')); ?>" class="relative w-full h-11 rounded-lg border border-stroke bg-white hover:bg-hover transition-colors text-[14px] font-semibold text-ink flex items-center justify-center">
          <span class="absolute left-4 top-1/2 -translate-y-1/2">
            <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.6l6.7-6.7C35.6 2.4 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.8 6.1C12.3 13.2 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.1 5.3-4.6 7l7.1 5.5c4.1-3.8 6.4-9.4 6.4-16z"/><path fill="#FBBC05" d="M10.4 28.3c-.5-1.4-.8-2.9-.8-4.3s.3-3 .8-4.3l-7.8-6.1C.9 16.6 0 20.2 0 24s.9 7.4 2.6 10.4l7.8-6.1z"/><path fill="#34A853" d="M24 48c6.2 0 11.5-2 15.3-5.5l-7.1-5.5c-2 1.3-4.6 2.1-8.2 2.1-6.3 0-11.7-3.7-13.6-9l-7.8 6.1C6.5 42.6 14.6 48 24 48z"/></svg>
          </span>
          Sign in with Google
        </a>
        <a href="<?php echo e(route('social.redirect', 'github')); ?>" class="relative w-full h-11 rounded-lg border border-stroke bg-white hover:bg-hover transition-colors text-[14px] font-semibold text-ink flex items-center justify-center">
          <span class="absolute left-4 top-1/2 -translate-y-1/2">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="#0f0f10"><path d="M12 .5C5.7.5.5 5.7.5 12c0 5.1 3.3 9.4 7.9 10.9.6.1.8-.3.8-.6v-2c-3.2.7-3.9-1.5-3.9-1.5-.5-1.3-1.3-1.7-1.3-1.7-1.1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1 1.8 2.7 1.3 3.4 1 .1-.8.4-1.3.7-1.6-2.6-.3-5.3-1.3-5.3-5.7 0-1.3.5-2.3 1.2-3.1-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.3 1.2a11.5 11.5 0 016 0C17.3 4.6 18.3 5 18.3 5c.6 1.6.2 2.8.1 3.1.8.8 1.2 1.8 1.2 3.1 0 4.4-2.7 5.4-5.3 5.7.4.4.8 1.1.8 2.2v3.3c0 .3.2.7.8.6 4.6-1.5 7.9-5.8 7.9-10.9C23.5 5.7 18.3.5 12 .5z"/></svg>
          </span>
          Sign in with GitHub
        </a>
        <button type="button" id="sso-btn" class="relative w-full h-11 rounded-lg border border-stroke bg-white hover:bg-hover transition-colors text-[14px] font-semibold text-ink">
          <span class="absolute left-4 top-1/2 -translate-y-1/2">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0f0f10" stroke-width="2"><circle cx="8" cy="8" r="4"/><path d="M11 11l8 8M16 16l2-2M19 19l2-2" stroke-linecap="round"/></svg>
          </span>
          Sign in with Single Sign-On
        </button>
      </div>

      <div class="flex items-center gap-3 my-6">
        <div class="h-px flex-1 bg-line"></div>
        <span class="text-[13px] text-faint">or</span>
        <div class="h-px flex-1 bg-line"></div>
      </div>

      
      <form id="signin-form" method="POST" action="<?php echo e(route('signin.store')); ?>">
        <?php echo csrf_field(); ?>

        <label class="block text-[13px] font-medium text-ink mb-1.5" for="email">Email</label>
        <div class="relative">
          <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" placeholder="name@company.com" class="pb-input has-suffix <?php echo e($errors->has('email') ? 'is-error' : ''); ?>" required />
          <button id="email-clear" type="button" class="hidden absolute right-3 top-1/2 -translate-y-1/2 text-faint hover:text-sub" title="Clear">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/><path d="M9 9l6 6M15 9l-6 6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
          </button>
        </div>

        <div id="pw-block" class="hidden mt-5">
          <label class="block text-[13px] font-medium text-ink mb-1.5" for="password">Password</label>
          <div class="relative">
            <input id="password" name="password" type="password" placeholder="Enter password" class="pb-input has-suffix" />
            <button id="pw-toggle" type="button" class="absolute right-3 top-1/2 -translate-y-1/2 text-faint hover:text-sub" title="Show password" aria-label="Show password">
              <svg id="eye-open" width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.7"/></svg>
            </button>
          </div>
          <button type="button" id="forgot-btn" class="inline-block mt-2 text-[13px] text-link font-medium hover:underline">Forgot your password?</button>
        </div>

        <button id="continue-btn" type="button" disabled
          class="mt-5 w-full h-11 rounded-lg bg-hover text-faint text-[14px] font-semibold cursor-not-allowed transition-colors">
          Continue
        </button>

        <button id="code-btn" type="button"
          class="hidden mt-3 w-full h-11 rounded-lg border border-stroke bg-white hover:bg-hover transition-colors text-[14px] font-semibold text-ink">
          Sign in with unique code
        </button>
      </form>

      
      <form id="sso-form" method="POST" action="<?php echo e(route('sso.start')); ?>" class="hidden">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="email" id="sso-email" />
      </form>

      <p class="mt-5 text-center text-[12px] text-sub leading-relaxed">
        By signing in, you understand and agree to
        our <a href="#" class="text-ink font-medium underline">Terms of Service</a>
        and <a href="#" class="text-ink font-medium underline">Privacy Policy</a>.
      </p>
    </div>
  </main>

  <script>
    (function () {
      var form = document.getElementById('signin-form');
      var email = document.getElementById('email');
      var clear = document.getElementById('email-clear');
      var pwBlock = document.getElementById('pw-block');
      var pw = document.getElementById('password');
      var pwToggle = document.getElementById('pw-toggle');
      var eye = document.getElementById('eye-open');
      var btn = document.getElementById('continue-btn');
      var codeBtn = document.getElementById('code-btn');
      var forgot = document.getElementById('forgot-btn');
      var ssoBtn = document.getElementById('sso-btn');
      var ssoForm = document.getElementById('sso-form');
      var ssoEmail = document.getElementById('sso-email');
      var step = 1;

      function validEmail() { return /\S+@\S+\.\S+/.test(email.value); }
      function setPrimary(on) {
        btn.disabled = !on;
        btn.classList.toggle('bg-hover', !on);
        btn.classList.toggle('text-faint', !on);
        btn.classList.toggle('cursor-not-allowed', !on);
        btn.classList.toggle('bg-brand', on);
        btn.classList.toggle('hover:bg-brand-dark', on);
        btn.classList.toggle('text-white', on);
      }
      function refresh() {
        clear.classList.toggle('hidden', email.value === '');
        if (step === 1) setPrimary(validEmail());
        else setPrimary(pw.value.trim() !== '');
      }
      function toStep2() {
        step = 2;
        pwBlock.classList.remove('hidden');
        codeBtn.classList.remove('hidden');
        refresh();
        setTimeout(function () { pw.focus(); }, 0);
      }
      function toStep1() {
        step = 1;
        pwBlock.classList.add('hidden');
        codeBtn.classList.add('hidden');
        pw.value = '';
        refresh();
        email.focus();
      }
      // Send a 6-digit code (passwordless): submit with an empty password.
      function submitWithCode() { pw.value = ''; form.submit(); }

      email.addEventListener('input', refresh);
      email.addEventListener('keydown', function (e) { if (e.key === 'Enter' && step === 1 && validEmail()) { e.preventDefault(); toStep2(); } });
      pw.addEventListener('input', refresh);
      pw.addEventListener('keydown', function (e) { if (e.key === 'Enter' && step === 2 && pw.value.trim()) { e.preventDefault(); form.submit(); } });

      clear.addEventListener('click', function () { email.value = ''; toStep1(); });

      pwToggle.addEventListener('click', function () {
        var show = pw.type === 'password';
        pw.type = show ? 'text' : 'password';
        pwToggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        eye.innerHTML = show
          ? '<path d="M3 3l18 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M10.6 5.2A9.9 9.9 0 0112 5c6.5 0 10 7 10 7a17 17 0 01-3.3 4.1M6.5 6.6A17 17 0 002 12s3.5 7 10 7a9.6 9.6 0 004.2-.9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.9 9.9a3 3 0 004.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>'
          : '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.7"/>';
      });

      btn.addEventListener('click', function () {
        if (btn.disabled) return;
        if (step === 1) toStep2();
        else form.submit(); // password login
      });
      codeBtn.addEventListener('click', submitWithCode);
      forgot.addEventListener('click', submitWithCode);

      ssoBtn.addEventListener('click', function () {
        if (!validEmail()) { toStep1(); email.focus(); return; }
        ssoEmail.value = email.value;
        ssoForm.submit();
      });

      // If the server returned a password error, jump straight to the password step.
      <?php if($startStep2): ?> toStep2(); <?php else: ?> refresh(); <?php endif; ?>
    })();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/rohitphilip/Sites/pblock3.0/resources/views/auth/signin.blade.php ENDPATH**/ ?>