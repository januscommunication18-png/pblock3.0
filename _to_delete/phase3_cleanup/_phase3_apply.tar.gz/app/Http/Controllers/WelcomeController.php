<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/**
 * Post-onboarding "Get started" home / app shell (spec §3, welcome.html POC).
 * Successful create / invite / skip flows all land here.
 */
class WelcomeController extends Controller
{
    /** GET /welcome */
    public function show(): View|RedirectResponse
    {
        $user = Auth::user();

        // No workspace yet -> send through first-workspace onboarding.
        if (! $user->workspaces()->exists()) {
            return redirect()->route('onboarding.workspace');
        }

        $current = $user->currentWorkspace ?? $user->workspaces()->first();

        // Workspaces for the switcher modal, with the user's role and member counts.
        $workspaces = $user->workspaces()
            ->withCount('memberships')
            ->orderBy('name')
            ->get()
            ->map(fn ($w) => [
                'id' => $w->id,
                'name' => $w->name,
                'slug' => $w->slug,
                'initial' => $w->initial(),
                'role' => ucfirst((string) $w->pivot->role),
                'members' => $w->memberships_count,
                'current' => $current && $w->id === $current->id,
            ])
            ->all();

        return view('app.welcome', [
            'user' => $user,
            'workspace' => $current,
            'workspaces' => $workspaces,
        ]);
    }
}
